# 🚀 Setup Guide: Baseball Projection Engine

Follow these steps exactly, in order. Each step has the command you need to copy-paste into your terminal.

---

## PHASE 1: Install Prerequisites (one-time, ~10 min)

### Step 1: Install Node.js

Node.js runs the dashboard. Download and install from:

👉 **https://nodejs.org** — click the **LTS** version (the green button)

Run through the installer with all default options. When it's done, open a **new** terminal and verify:

```bash
node --version
```

You should see something like `v20.x.x` or `v22.x.x`. If you see an error, restart your terminal.

### Step 2: Install Git

Git lets you push code to GitHub. Download from:

👉 **https://git-scm.com/downloads**

Install with defaults. Verify:

```bash
git --version
```

### Step 3: Create Accounts (if you don't have them)

- **GitHub**: https://github.com/signup (free — this is where your code lives publicly)
- **Vercel**: https://vercel.com/signup (free — sign up with your GitHub account, this is easiest)

---

## PHASE 2: Set Up the Project (~5 min)

### Step 4: Create a folder and initialize

Open your terminal. Navigate to where you want the project (e.g., your Desktop or a projects folder):

```bash
# Mac/Linux:
cd ~/Desktop

# Windows (PowerShell):
cd $HOME\Desktop
```

Create the project:

```bash
mkdir baseball-projection-engine
cd baseball-projection-engine
```

### Step 5: Initialize Git

```bash
git init
```

### Step 6: Create all the project files

You have two options here:

**Option A — Download from Claude (easiest)**:
Download the files I gave you and place them in the folder matching this structure:

```
baseball-projection-engine/
├── index.html
├── package.json
├── vite.config.js
├── .gitignore
├── README.md
├── src/
│   ├── main.jsx
│   └── App.jsx          ← this is the big dashboard file
└── scripts/
    ├── data_pipeline.py
    └── requirements.txt
```

**Option B — Clone a template** (if I've already pushed it):
```bash
git clone https://github.com/YOUR_USERNAME/baseball-projection-engine.git
cd baseball-projection-engine
```

### Step 7: Install JavaScript dependencies

```bash
npm install
```

This downloads React, Recharts, and everything else listed in `package.json`. It creates a `node_modules/` folder (don't touch it) and a `package-lock.json` file.

It might take 30-60 seconds. You'll see some output — warnings are fine, errors are not.

### Step 8: Test locally

```bash
npm run dev
```

You should see output like:

```
  VITE v5.4.x  ready in 300ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: http://192.168.x.x:5173/
```

**Open http://localhost:5173 in your browser.** You should see the dashboard. Try searching for "Juan Soto" — it should pull real stats from the MLB API.

Press `Ctrl+C` in the terminal to stop the server when you're done testing.

---

## PHASE 3: Push to GitHub (~5 min)

### Step 9: Create a GitHub repository

1. Go to https://github.com/new
2. Name: `baseball-projection-engine`
3. Description: `MLB player projection system — WAR, wRC+, OPS forecasting with Marcel methodology`
4. Set to **Public** (this is your portfolio piece!)
5. Do **NOT** check "Add a README" (we already have one)
6. Click **Create repository**

### Step 10: Push your code

GitHub will show you commands. Use these (replace YOUR_USERNAME):

```bash
git add .
git commit -m "Initial commit: Marcel projection engine with MLB Stats API integration"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/baseball-projection-engine.git
git push -u origin main
```

It will ask for your GitHub credentials. If you have 2FA enabled, you'll need a [Personal Access Token](https://github.com/settings/tokens) instead of your password.

After pushing, refresh your GitHub repo page — you should see all your files and the README rendered nicely.

---

## PHASE 4: Deploy to Vercel (~3 min)

### Option A: Vercel Dashboard (no CLI needed)

1. Go to **https://vercel.com/new**
2. Click **Import Git Repository**
3. Select your `baseball-projection-engine` repo
4. Vercel auto-detects Vite. The default settings are correct:
   - Framework Preset: **Vite**
   - Build Command: `npm run build`
   - Output Directory: `dist`
5. Click **Deploy**

In ~60 seconds your site is live at `https://baseball-projection-engine.vercel.app` (or similar).

**Every time you push to GitHub, Vercel automatically redeploys.** 🎉

### Option B: Vercel CLI

```bash
# Install the CLI globally
npm install -g vercel

# Deploy (follow prompts — say yes to everything)
vercel

# For production deployment:
vercel --prod
```

---

## PHASE 5: Python Pipeline (optional, for deeper analysis)

This is separate from the dashboard. It pulls richer data from FanGraphs and Statcast.

### Step 11: Install Python dependencies

```bash
cd scripts
pip install -r requirements.txt
```

If `pip` doesn't work, try `pip3`. If that doesn't work, you may need to install Python from https://python.org.

### Step 12: Run projections

```bash
# Single player
python data_pipeline.py --player "Juan Soto"

# Backtest (measures accuracy)
python data_pipeline.py --backtest

# All qualified hitters
python data_pipeline.py --full
```

Output goes to `scripts/data/`. The first run takes a few minutes because pybaseball is downloading data from FanGraphs.

---

## What to Do Next

Once everything is deployed, here's how to make this stand out for front office applications:

### Immediate wins
- [ ] Update the README with your real Vercel URL
- [ ] Run the backtest (`--backtest`) and add real RMSE numbers to the README
- [ ] Add your name and contact info to the README
- [ ] Pin the repo on your GitHub profile

### Level-up additions
- [ ] **Blog post**: Write a 1,000-word post explaining your methodology decisions on Medium or Substack — link it from the README
- [ ] **Statcast integration**: Use the Python pipeline to pull xwOBA/barrel% and show it in the dashboard
- [ ] **Minor league projections**: Add level-specific translation factors
- [ ] **Comp analysis**: Compare your projections to Steamer/ZiPS, show where you agree and disagree
- [ ] **Twitter/X presence**: Share interesting projections with charts — tag baseball analytics accounts

### How to update the site
```bash
# Make changes to any file, then:
git add .
git commit -m "describe what you changed"
git push
```
Vercel deploys automatically. Your live site updates in ~60 seconds.

---

## Troubleshooting

**"npm: command not found"**
→ Node.js isn't installed or your terminal needs restarting. Close and reopen terminal.

**"git: command not found"**
→ Git isn't installed. Download from https://git-scm.com.

**Dashboard loads but search doesn't work**
→ The MLB Stats API might be down or rate-limiting you. Refresh and try again. The API is free but occasionally slow.

**"CORS error" in browser console**
→ The MLB Stats API allows CORS from localhost and deployed sites. If you're still hitting issues, it's usually a network/firewall thing.

**Python pipeline errors about pybaseball**
→ Run `pip install --upgrade pybaseball`. Some versions have scraping issues when FanGraphs changes their HTML.

**Vercel build fails**
→ Check the build log on your Vercel dashboard. Most common issue: a missing file or import. Make sure all files match the structure above.

---

## Files Reference

| File | What it does |
|------|-------------|
| `package.json` | Lists JS dependencies — React, Recharts, Vite |
| `vite.config.js` | Build tool configuration |
| `index.html` | HTML shell with dark theme styles |
| `src/main.jsx` | Mounts React to the page |
| `src/App.jsx` | **The entire dashboard** — projection engine, charts, API calls |
| `scripts/data_pipeline.py` | FanGraphs/Statcast data collection + Marcel projections |
| `scripts/requirements.txt` | Python dependencies |
| `README.md` | Documentation + methodology (shows on GitHub) |
| `.gitignore` | Tells Git to skip node_modules, etc. |

---

*Total time: ~25 minutes from zero to a live, deployed projection system on your public GitHub.*
