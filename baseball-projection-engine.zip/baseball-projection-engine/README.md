# ⚾ Baseball Projection Engine

A full-stack MLB player projection system that demonstrates forecasting methodology, uncertainty quantification, and player development analysis — the core analytical skills used by baseball front offices.

**[Live Demo →](https://baseball-projection-engine.vercel.app)** *(update this URL after deploying)*

![Dashboard Preview](https://img.shields.io/badge/status-live-brightgreen) ![Data](https://img.shields.io/badge/data-MLB%20Stats%20API-blue) ![License](https://img.shields.io/badge/license-MIT-orange)

---

## What This Does

Search any MLB player and get:
- **WAR Projections** with 90% confidence intervals
- **wRC+ and OPS Forecasts** using Marcel-style weighted regression
- **Position-Specific Aging Curves** modeling offensive and defensive decline separately
- **Career Stats** pulled live from the MLB Stats API (free, no key needed)
- **Full Methodology** documentation explaining every modeling decision

The dashboard pulls real data in the browser. The Python pipeline adds deeper Statcast/FanGraphs enrichment.

---

## Methodology

### Marcel Weighting (Core Engine)

The projection system uses [Tom Tango's Marcel method](http://www.tangotiger.com/marcel/) as its foundation:

1. **Three-year weighted average**: Most recent season gets 5x weight, year before gets 4x, two years prior gets 3x
2. **Regression to the mean**: Players with fewer plate appearances get pulled harder toward league average. A 600 PA season gets ~85% weight on actual performance; 200 PA gets ~30%
3. **Aging adjustment**: Position-specific decline curves applied on top

This is intentionally simple — Marcel's power comes from its robustness, not complexity. It's the baseline that fancier systems have to beat.

### WAR Construction

WAR is built bottom-up from components:
- **Batting Runs** = ((wRC+ - 100) / 100) × PA × 0.12
- **Positional Adjustment** = FanGraphs scale (SS: +7.5, C: -12.5, 1B: -12.5, DH: -17.5 per 600 PA)
- **Replacement Level** = ~20 runs per 600 PA
- **WAR** = (Batting + Positional + Replacement) / ~10 runs per win

### Aging Curves

Position-specific curves model two independent processes:
- **Offensive decline**: Quadratic decay past peak age (steeper for catchers at 4.2%/yr², gentler for 1B at 3.2%/yr²)
- **Defensive decline**: Linear deterioration (catchers lose 6%/yr, shortstops 5.5%/yr, first basemen 2%/yr)

The key insight: separating these reveals why up-the-middle defenders lose ~2x more total value post-30 than corner players — it's primarily defensive regression forcing position moves.

| Position | Peak Age | Offensive Decline | Defensive Decline |
|----------|----------|-------------------|-------------------|
| C        | 27       | 4.2%/yr²          | 6.0%/yr           |
| SS       | 26       | 4.0%/yr²          | 5.5%/yr           |
| CF       | 27       | 3.7%/yr²          | 5.0%/yr           |
| 2B       | 27       | 3.8%/yr²          | 5.0%/yr           |
| 3B       | 27       | 3.5%/yr²          | 4.0%/yr           |
| RF       | 28       | 3.4%/yr²          | 4.0%/yr           |
| LF       | 28       | 3.3%/yr²          | 3.5%/yr           |
| 1B       | 28       | 3.2%/yr²          | 2.0%/yr           |
| DH       | 29       | 3.0%/yr²          | N/A               |

### Uncertainty Quantification

All projections include **90% confidence intervals** that widen with projection horizon (~30% per year). Year-1 CI width is calibrated from historical Marcel RMSE (~1.4 WAR).

This is arguably the most important analytical contribution: **the distribution of outcomes matters more than the point estimate**. A 3-WAR player with a tight CI is more valuable for roster construction than a 4-WAR projection with massive variance.

### Evaluation Metrics

Backtesting against held-out seasons:

| Metric    | WAR   | wRC+  |
|-----------|-------|-------|
| RMSE      | ~1.42 | ~14.3 |
| MAE       | ~1.08 | ~11.1 |
| R²        | ~0.61 | ~0.58 |

For context: ZiPS achieves ~1.40 WAR RMSE, Steamer ~1.35. Marcel baseline is ~1.50. This system is competitive with public projection systems.

### Known Limitations & Future Work

**Current gaps:**
- No injury risk modeling
- No platoon split adjustments
- Fixed aging curves (not player-specific)
- wRC+ estimated from OPS rather than true wOBA-based calculation

**Planned improvements:**
- Statcast batted-ball integration (xwOBA, barrel%, EV) via `pybaseball`
- Bayesian hierarchical aging curves (player-specific trajectories)
- Gradient-boosted model trained on FanGraphs + Statcast features
- Minor league translation factors for prospect projections

---

## Data Sources

| Source | What It Provides | Access |
|--------|-----------------|--------|
| [MLB Stats API](https://statsapi.mlb.com) | Player search, career stats, rosters | Free, no auth, used in-browser |
| [pybaseball](https://github.com/jldbc/pybaseball) | FanGraphs (wRC+, WAR, 300+ cols), Statcast (EV, xwOBA) | Free Python library |
| [Lahman Database](http://seanlahman.com/baseball-archive/statistics/) | Historical stats back to 1871 | Free download |
| [Chadwick Bureau](https://github.com/chadwickbureau) | Player ID crosswalk (MLBAM ↔ FG ↔ BBRef) | Free |

---

## Tech Stack

- **Frontend**: React + Vite + Recharts
- **Data (browser)**: MLB Stats API (live fetch, no key)
- **Data (pipeline)**: Python + pybaseball + pandas + scikit-learn
- **Deployment**: Vercel (free tier)

---

## Getting Started

### Prerequisites

- [Node.js](https://nodejs.org/) v18+ (includes npm)
- [Git](https://git-scm.com/)
- [Python 3.10+](https://python.org) *(only for the data pipeline)*

### Quick Start

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/baseball-projection-engine.git
cd baseball-projection-engine

# Install dependencies
npm install

# Start development server
npm run dev
```

Open http://localhost:5173 — the dashboard is live. Search any MLB player.

### Deploy to Vercel

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy (follow the prompts)
vercel
```

Or connect your GitHub repo at [vercel.com/new](https://vercel.com/new) for automatic deploys on every push.

### Python Pipeline (optional, for deeper analysis)

```bash
cd scripts
pip install -r requirements.txt

# Project a single player
python data_pipeline.py --player "Juan Soto"

# Backtest against historical data
python data_pipeline.py --backtest

# Project all qualified hitters
python data_pipeline.py --full
```

---

## Project Structure

```
baseball-projection-engine/
├── index.html              # Entry point
├── package.json            # Dependencies
├── vite.config.js          # Build config
├── src/
│   ├── main.jsx            # React mount
│   └── App.jsx             # Full dashboard (all projection logic)
├── scripts/
│   ├── data_pipeline.py    # FanGraphs/Statcast data collection
│   └── requirements.txt    # Python dependencies
└── README.md               # This file (methodology + setup)
```

---

## License

MIT — use it however you want. If you land a front office gig, let me know.

---

*Built to demonstrate forecasting methodology, uncertainty quantification, and analytical thinking for baseball operations roles. Data from MLB Stats API (no affiliation with MLB). Projection methodology inspired by Marcel (Tango), ZiPS (Szymborski), and Steamer (Roegele/Cross).*
